import React, { useEffect, useState } from 'react';
import { api, getUser } from '../api';

export default function ProductDetails({ id }) {
  const [product, setProduct] = useState(null);
  const [variants, setVariants] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [selected, setSelected] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    Promise.all([api.product(id), api.variants(id), api.reviews(id)])
      .then(([p, v, r]) => {
        setProduct(p);
        setVariants(v);
        setReviews(r);
        if (v[0]) setSelected(v[0].id);
      })
      .catch(err => setMessage(err.message));
  }, [id]);

  async function addToCart() {
    if (!getUser()) {
      window.location.hash = '/login';
      return;
    }
    if (!selected) {
      setMessage('No variant is available for this product.');
      return;
    }
    try {
      await api.addCartItem({ variantId: selected, quantity: 1 });
      setMessage('Added to cart.');
    } catch (err) {
      setMessage(err.message);
    }
  }

  if (!product) return <p>{message || 'Loading...'}</p>;

  return (
    <div>
      {message && <div className="success">{message}</div>}
      <div className="card">
        <div className="row">
          <div style={{ flex: 1 }}>
            {product.imageUrl && <img className="product-image" src={product.imageUrl} alt={product.title} />}
            <h1>{product.title}</h1>
            <p>{product.description}</p>
            <h2>₹{Number(product.sellingPrice).toLocaleString('en-IN')}</h2>
            <p className="muted">Category: {product.category?.name}</p>
          </div>
          <div style={{ minWidth: 260 }}>
            <h3>Choose variant</h3>
            {variants.map(v => (
              <label key={v.id} style={{ display: 'block', margin: '10px 0' }}>
                <input type="radio" checked={selected === v.id} onChange={() => setSelected(v.id)} />{' '}
                {v.sku} — {v.colour || ''} {v.size || ''} — ₹{Number(v.price).toLocaleString('en-IN')} — stock {v.stockQuantity}
              </label>
            ))}
            <button className="button" onClick={addToCart}>Add to Cart</button>
            <br /><br />
            <a href="#/marketplace">Back to Marketplace</a>
          </div>
        </div>
      </div>
      <h2>Reviews</h2>
      {reviews.length ? reviews.map(review => <div className="card" key={review.id}><strong>{'★'.repeat(review.rating)}</strong><p>{review.comment}</p></div>) : <p className="muted">No reviews yet.</p>}
    </div>
  );
}
