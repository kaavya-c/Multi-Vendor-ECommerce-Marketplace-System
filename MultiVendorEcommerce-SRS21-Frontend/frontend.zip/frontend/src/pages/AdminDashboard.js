import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function AdminDashboard() {
  const [vendors, setVendors] = useState([]);
  const [message, setMessage] = useState('');

  async function load() {
    try { setVendors(await api.adminVendors()); } catch (err) { setMessage(err.message); }
  }
  useEffect(() => { load(); }, []);

  async function approve(id) {
    try { await api.approveVendor(id); await load(); setMessage('Vendor approved. Ask the vendor to log in again to receive a VENDOR JWT.'); } catch (err) { setMessage(err.message); }
  }

  async function reject(id) {
    try { await api.rejectVendor(id); await load(); setMessage('Vendor application rejected.'); } catch (err) { setMessage(err.message); }
  }

  return (
    <div>
      <h1>Admin Console</h1>
      {message && <div className="success">{message}</div>}
      <div className="table-wrap"><table><thead><tr><th>Business</th><th>Type</th><th>GSTIN</th><th>Status</th><th>Action</th></tr></thead><tbody>{vendors.map(v => <tr key={v.id}><td>{v.businessName}</td><td>{v.businessType}</td><td>{v.gstin || '-'}</td><td>{v.status}</td><td>{v.status === 'PENDING' && <div className="actions"><button className="button small" onClick={() => approve(v.id)}>Approve</button><button className="button danger small" onClick={() => reject(v.id)}>Reject</button></div>}</td></tr>)}</tbody></table></div>
    </div>
  );
}
