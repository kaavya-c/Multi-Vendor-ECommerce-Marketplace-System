import React from 'react';

export default function Home() {
  return (
    <>
      <section className="hero">
        <p className="muted">SRS-21 • Multi-Vendor E-Commerce Marketplace</p>
        <h1>One marketplace. Multiple trusted sellers.</h1>
        <p className="muted">
          Browse products, manage your cart, checkout securely, track orders and apply to become a vendor.
        </p>
        <div className="actions">
          <a className="button" href="#/marketplace">Start Shopping</a>
          <a className="button secondary" href="#/vendor/register">Become a Seller</a>
        </div>
      </section>
      <div className="grid">
        <div className="card"><h3>Buyer Storefront</h3><p className="muted">Products, variants, cart, checkout, orders, returns and reviews.</p></div>
        <div className="card"><h3>Vendor Onboarding</h3><p className="muted">Seller application stays pending until admin approval.</p></div>
        <div className="card"><h3>Admin Console</h3><p className="muted">Approve or reject vendor applications and manage disputes.</p></div>
      </div>
    </>
  );
}
