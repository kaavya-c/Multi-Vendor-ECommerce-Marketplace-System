import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function VendorDashboard() {
  const [vendor, setVendor] = useState(null);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [orders, setOrders] = useState([]);
  const [message, setMessage] = useState('');
  const [awbInputs, setAwbInputs] = useState({});

  const [product, setProduct] = useState({
    title: '',
    description: '',
    brand: '',
    hsnCode: '',
    mrp: '',
    sellingPrice: '',
    categoryId: '',
    imageUrl: ''
  });

  const [variant, setVariant] = useState({
    productId: '',
    sku: '',
    size: '',
    colour: '',
    material: '',
    price: '',
    stockQuantity: ''
  });

  const [showVariantForm, setShowVariantForm] = useState(false);

  async function load() {
    try {
      const [v, p, c, o] = await Promise.all([
        api.myVendor(),
        api.myProducts(),
        api.categories(),
        api.vendorOrders()
      ]);

      setVendor(v);
      setProducts(p);
      setCategories(c);
      setOrders(o);
    } catch (err) {
      setMessage(err.message);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function create(event) {
    event.preventDefault();

    try {
      const created = await api.createProduct({
        ...product,
        mrp: Number(product.mrp),
        sellingPrice: Number(product.sellingPrice)
      });

      setProducts([...products, created]);

      setMessage(
          'Product created with PENDING status. Add a variant, then publish it.'
      );

      setProduct({
        title: '',
        description: '',
        brand: '',
        hsnCode: '',
        mrp: '',
        sellingPrice: '',
        categoryId: '',
        imageUrl: ''
      });

    } catch (err) {
      setMessage(err.message);
    }
  }

  async function addVariant(event) {
    event.preventDefault();

    try {
      await api.addVariant(variant.productId, {
        sku: variant.sku,
        size: variant.size,
        colour: variant.colour,
        material: variant.material,
        price: Number(variant.price),
        stockQuantity: Number(variant.stockQuantity)
      });

      setMessage(
          'Variant added successfully. You can now publish the product.'
      );

      setShowVariantForm(false);

      setVariant({
        productId: '',
        sku: '',
        size: '',
        colour: '',
        material: '',
        price: '',
        stockQuantity: ''
      });

      await load();

    } catch (err) {
      setMessage(err.message);
    }
  }

  async function publish(id) {
    try {
      await api.publishProduct(id);
      await load();
      setMessage('Product published successfully.');
    } catch (err) {
      setMessage(err.message);
    }
  }

  async function updateOrderStatus(subOrderId, status) {
    try {
      await api.updateSubOrderStatus(subOrderId, status);
      await load();
      setMessage(`Order status updated to ${status}.`);
    } catch (err) {
      setMessage(err.message);
    }
  }

  async function updateAwb(subOrderId) {
    const awbNumber = awbInputs[subOrderId];

    if (!awbNumber || awbNumber.trim() === '') {
      setMessage('Please enter an AWB number.');
      return;
    }

    try {
      await api.updateAwb(subOrderId, awbNumber);
      await load();

      setMessage('AWB number saved successfully.');

      setAwbInputs({
        ...awbInputs,
        [subOrderId]: ''
      });

    } catch (err) {
      setMessage(err.message);
    }
  }

  function openVariantForm(product) {
    setVariant({
      productId: product.id,
      sku: '',
      size: '',
      colour: '',
      material: '',
      price: product.sellingPrice,
      stockQuantity: ''
    });

    setShowVariantForm(true);
    setMessage('');
  }

  return (
      <div>
        <h1>Vendor Dashboard</h1>

        {message && (
            <div className="notice">
              {message}
            </div>
        )}

        {vendor && (
            <div className="card">
              <h3>{vendor.storeName || vendor.businessName}</h3>

              <p>
                Status: <strong>{vendor.status}</strong>
              </p>

              <p>
                GST verified: {String(vendor.gstVerified)}
                {' • '}
                Bank verified: {String(vendor.bankVerified)}
              </p>
            </div>
        )}

        {vendor?.status === 'APPROVED' && (
            <>
              <h2>Create Product</h2>

              <form className="form" onSubmit={create}>
                <label>Title</label>

                <input
                    value={product.title}
                    onChange={e =>
                        setProduct({
                          ...product,
                          title: e.target.value
                        })
                    }
                    required
                />

                <label>Description</label>

                <textarea
                    value={product.description}
                    onChange={e =>
                        setProduct({
                          ...product,
                          description: e.target.value
                        })
                    }
                />

                <label>Brand</label>

                <input
                    value={product.brand}
                    onChange={e =>
                        setProduct({
                          ...product,
                          brand: e.target.value
                        })
                    }
                />

                <label>HSN code</label>

                <input
                    value={product.hsnCode}
                    onChange={e =>
                        setProduct({
                          ...product,
                          hsnCode: e.target.value
                        })
                    }
                />

                <label>MRP</label>

                <input
                    type="number"
                    value={product.mrp}
                    onChange={e =>
                        setProduct({
                          ...product,
                          mrp: e.target.value
                        })
                    }
                    required
                />

                <label>Selling price</label>

                <input
                    type="number"
                    value={product.sellingPrice}
                    onChange={e =>
                        setProduct({
                          ...product,
                          sellingPrice: e.target.value
                        })
                    }
                    required
                />

                <label>Category</label>

                <select
                    value={product.categoryId}
                    onChange={e =>
                        setProduct({
                          ...product,
                          categoryId: e.target.value
                        })
                    }
                    required
                >
                  <option value="">Select category</option>

                  {categories.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                  ))}
                </select>

                <label>Image URL</label>

                <input
                    value={product.imageUrl}
                    onChange={e =>
                        setProduct({
                          ...product,
                          imageUrl: e.target.value
                        })
                    }
                />

                <button className="button">
                  Create Product
                </button>
              </form>
            </>
        )}

        <h2>My Products</h2>

        <div className="table-wrap">
          <table>
            <thead>
            <tr>
              <th>Product</th>
              <th>Status</th>
              <th>Price</th>
              <th>Action</th>
            </tr>
            </thead>

            <tbody>
            {products.map(p => (
                <tr key={p.id}>
                  <td>{p.title}</td>

                  <td>{p.status}</td>

                  <td>₹{p.sellingPrice}</td>

                  <td>
                    <button
                        className="button small"
                        disabled={p.status === 'ACTIVE'}
                        onClick={() => openVariantForm(p)}
                    >
                      Add Variant
                    </button>

                    {' '}

                    <button
                        className="button small"
                        disabled={p.status === 'ACTIVE'}
                        onClick={() => publish(p.id)}
                    >
                      Publish
                    </button>
                  </td>
                </tr>
            ))}
            </tbody>
          </table>
        </div>

        <h2>My Orders</h2>

        <div className="table-wrap">
          <table>
            <thead>
            <tr>
              <th>Order ID</th>
              <th>Items</th>
              <th>Total</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
            </thead>

            <tbody>
            {orders.length === 0 ? (
                <tr>
                  <td colSpan="5">No orders yet.</td>
                </tr>
            ) : (
                orders.map(order => {
                  const subOrder = order.subOrders?.find(
                      s => s.vendor?.id === vendor?.id
                  );

                  const vendorItems = order.items?.filter(
                      item => item.vendorId === vendor?.id
                  ) || [];

                  return (
                      <tr key={order.id}>
                        <td>{order.id}</td>

                        <td>
                          {vendorItems.map(item => (
                              <div key={item.id}>
                                {item.variant?.sku} × {item.quantity}
                              </div>
                          ))}
                        </td>

                        <td>
                          ₹{vendorItems.reduce(
                            (total, item) => total + (item.unitPrice * item.quantity),
                            0
                        )}
                        </td>

                        <td>
                          <strong>{subOrder?.status || order.status}</strong>

                          {subOrder?.awbNumber && (
                              <div>
                                <strong>AWB:</strong> {subOrder.awbNumber}
                              </div>
                          )}
                        </td>

                        <td>

                          {subOrder?.status === 'PACKED' && (
                              <div>
                                <input
                                    type="text"
                                    placeholder="Enter AWB number"
                                    value={awbInputs[subOrder.id] || ''}
                                    onChange={e =>
                                        setAwbInputs({
                                          ...awbInputs,
                                          [subOrder.id]: e.target.value
                                        })
                                    }
                                />

                                <button
                                    className="button small"
                                    onClick={() => updateAwb(subOrder.id)}
                                >
                                  Save AWB
                                </button>
                              </div>
                          )}

                          {subOrder?.status === 'PLACED' && (
                              <>
                                <button
                                    className="button small"
                                    onClick={() =>
                                        updateOrderStatus(subOrder.id, 'CONFIRMED')
                                    }
                                >
                                  Confirm
                                </button>

                                {' '}

                                <button
                                    className="button small"
                                    onClick={() =>
                                        updateOrderStatus(subOrder.id, 'CANCELLED')
                                    }
                                >
                                  Reject
                                </button>
                              </>
                          )}

                          {subOrder?.status === 'CONFIRMED' && (
                              <button
                                  className="button small"
                                  onClick={() =>
                                      updateOrderStatus(subOrder.id, 'PACKED')
                                  }
                              >
                                Mark Packed
                              </button>
                          )}

                          {subOrder?.status === 'PACKED' && (
                              <button
                                  className="button small"
                                  disabled={!subOrder.awbNumber}
                                  onClick={() =>
                                      updateOrderStatus(subOrder.id, 'DISPATCHED')
                                  }
                              >
                                Mark Dispatched
                              </button>
                          )}

                          {subOrder?.status === 'DISPATCHED' && (
                              <button
                                  className="button small"
                                  onClick={() =>
                                      updateOrderStatus(subOrder.id, 'DELIVERED')
                                  }
                              >
                                Mark Delivered
                              </button>
                          )}
                        </td>
                      </tr>
                  );
                })
            )}
            </tbody>
          </table>
        </div>

        {showVariantForm && (
            <div className="card">
              <h2>Add Product Variant</h2>

              <form className="form" onSubmit={addVariant}>
                <label>SKU</label>

                <input
                    value={variant.sku}
                    onChange={e =>
                        setVariant({
                          ...variant,
                          sku: e.target.value
                        })
                    }
                    placeholder="Example: VIVO-Y32-BLK-128"
                    required
                />

                <label>Size</label>

                <input
                    value={variant.size}
                    onChange={e =>
                        setVariant({
                          ...variant,
                          size: e.target.value
                        })
                    }
                    placeholder="Example: 128GB"
                />

                <label>Colour</label>

                <input
                    value={variant.colour}
                    onChange={e =>
                        setVariant({
                          ...variant,
                          colour: e.target.value
                        })
                    }
                    placeholder="Example: Black"
                />

                <label>Material</label>

                <input
                    value={variant.material}
                    onChange={e =>
                        setVariant({
                          ...variant,
                          material: e.target.value
                        })
                    }
                    placeholder="Example: Glass"
                />

                <label>Price</label>

                <input
                    type="number"
                    value={variant.price}
                    onChange={e =>
                        setVariant({
                          ...variant,
                          price: e.target.value
                        })
                    }
                    required
                />

                <label>Stock Quantity</label>

                <input
                    type="number"
                    min="0"
                    value={variant.stockQuantity}
                    onChange={e =>
                        setVariant({
                          ...variant,
                          stockQuantity: e.target.value
                        })
                    }
                    required
                />

                <button className="button">
                  Add Variant
                </button>

                <button
                    type="button"
                    className="button"
                    onClick={() => setShowVariantForm(false)}
                >
                  Cancel
                </button>
              </form>
            </div>
        )}
      </div>
  );
}