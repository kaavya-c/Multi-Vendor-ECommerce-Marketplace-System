import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function Marketplace() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [error, setError] = useState('');

  async function load(term = '') {
    try {
      setProducts(await api.products(term));
      setError('');
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => { load(); }, []);

  function submit(event) {
    event.preventDefault();
    load(search);
  }

  return (
    <div>
      <div className="row">
        <div><h1>Marketplace</h1><p className="muted">Active products from approved vendors.</p></div>
        <form onSubmit={submit} style={{ minWidth: 300 }}>
          <input className="search" placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)} />
        </form>
      </div>
      {error && <div className="notice">{error}</div>}
      <div className="grid">
        {products.map(product => (
          <a className="card" href={`#/products/${product.id}`} key={product.id}>
            {product.imageUrl ? <img className="product-image" src={product.imageUrl} alt={product.title} /> : <div className="product-image" />}
            <h3>{product.title}</h3>
            <p className="muted">{product.brand || 'Marketplace seller'}</p>
            <strong>₹{Number(product.sellingPrice).toLocaleString('en-IN')}</strong>
            <p className="muted">{product.category?.name}</p>
          </a>
        ))}
      </div>
      {!products.length && <div className="card"><p>No active products yet. An approved vendor needs to create and publish a product.</p></div>}
    </div>
  );
}
