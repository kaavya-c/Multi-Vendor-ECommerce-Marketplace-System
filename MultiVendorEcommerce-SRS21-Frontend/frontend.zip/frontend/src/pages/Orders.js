import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [returns, setReturns] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    Promise.all([
      api.orders(),
      api.returns()
    ])
        .then(([ordersData, returnsData]) => {
          setOrders(ordersData);
          setReturns(returnsData);
        })
        .catch(err => setMessage(err.message));
  }, []);

  async function requestReturn(subOrderId) {
    try {
      await api.createReturn({
        subOrderId,
        reason: 'Changed mind'
      });

      setMessage('Return request created.');

      // Reload returns so the new return status appears immediately
      const updatedReturns = await api.returns();
      setReturns(updatedReturns);

    } catch (err) {
      setMessage(err.message);
    }
  }

  async function cancelOrder(subOrderId) {
    try {
      await api.cancelSubOrder(subOrderId);

      setMessage('Order cancelled successfully.');

      // Reload orders so the updated status appears immediately
      const updatedOrders = await api.orders();
      setOrders(updatedOrders);

    } catch (err) {
      setMessage(err.message);
    }
  }

  function getReturnRequest(subOrderId) {
    const matchingReturns = returns.filter(
        returnRequest => returnRequest.subOrderId === subOrderId
    );

    if (matchingReturns.length === 0) {
      return null;
    }

    return matchingReturns.reduce((latest, current) => {
      return new Date(current.createdAt) > new Date(latest.createdAt)
          ? current
          : latest;
    });
  }

  return (
      <div>
        <h1>My Orders</h1>

        {message && (
            <div className="success">
              {message}
            </div>
        )}

        {orders.map(order => (
            <div className="card" key={order.id}>

              <div className="row">
                <strong>Order {order.id}</strong>
              </div>

              <p>
                Total: ₹
                {Number(order.totalAmount).toLocaleString('en-IN')}
              </p>

              <p>
                Payment: {order.paymentStatus}
              </p>

              <h3>Items</h3>

              <ul>
                {order.items.map(item => (
                    <li key={item.id}>
                      {item.variant.sku} × {item.quantity} — ₹
                      {Number(item.unitPrice).toLocaleString('en-IN')}
                    </li>
                ))}
              </ul>

              <h3>Vendor Orders</h3>

              {order.subOrders?.map(subOrder => {

                const returnRequest = getReturnRequest(subOrder.id);

                return (
                    <div className="card" key={subOrder.id}>

                      <p>
                        <strong>Vendor:</strong>{' '}
                        {subOrder.vendor?.storeName ||
                            subOrder.vendor?.name ||
                            'Vendor'}
                      </p>

                      <p>
                        <strong>Status:</strong>{' '}
                        {subOrder.status}
                      </p>

                      {subOrder.awbNumber && (
                          <>
                            <p>
                              <strong>AWB:</strong>{' '}
                              {subOrder.awbNumber}
                            </p>

                            <button
                                className="button"
                                onClick={() =>
                                    alert(
                                        `Tracking AWB: ${subOrder.awbNumber}`
                                    )
                                }
                            >
                              Track Order
                            </button>
                          </>
                      )}

                      {subOrder.status === 'PLACED' ||
                      subOrder.status === 'CONFIRMED' ||
                      subOrder.status === 'PACKED' ? (
                          <button
                              className="button secondary"
                              onClick={() => cancelOrder(subOrder.id)}
                          >
                            Cancel Order
                          </button>
                      ) : null}

                      {returnRequest ? (
                          <>
                            <p>
                              <strong>Return Status:</strong>{' '}
                              {returnRequest.status}
                            </p>

                            <p>
                              <strong>Refund Amount:</strong>{' '}
                              ₹
                              {Number(
                                  returnRequest.refundAmount
                              ).toLocaleString('en-IN')}
                            </p>
                          </>
                      ) : (
                          subOrder.status === 'DELIVERED' && (
                              <button
                                  className="button secondary"
                                  onClick={() =>
                                      requestReturn(subOrder.id)
                                  }
                              >
                                Request Return
                              </button>
                          )
                      )}

                    </div>
                );
              })}

            </div>
        ))}

        {!orders.length && (
            <p className="muted">
              No orders yet.
            </p>
        )}
      </div>
  );
}