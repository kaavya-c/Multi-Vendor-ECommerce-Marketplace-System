import React, { useEffect, useState } from 'react';
import { api } from '../api';

export default function Cart() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');

  async function load() {
    try { setItems(await api.cart()); } catch (err) { setError(err.message); }
  }
  useEffect(() => { load(); }, []);

  async function remove(id) {
    try { await api.removeCartItem(id); load(); } catch (err) { setError(err.message); }
  }

  const total = items.reduce((sum, item) => sum + item.variant.price * item.quantity, 0);

  return (
    <div>
      <h1>Cart</h1>
      {error && <div className="notice">{error}</div>}
      {items.map(item => (
        <div className="card row" key={item.id}>
          <div><strong>{item.variant.product?.title || item.variant.sku}</strong><p className="muted">SKU: {item.variant.sku}</p></div>
          <div>₹{Number(item.variant.price).toLocaleString('en-IN')} × {item.quantity}</div>
          <button className="button danger" onClick={() => remove(item.id)}>Remove</button>
        </div>
      ))}
      {!items.length && <div className="card">Your cart is empty. <a href="#/marketplace">Continue shopping</a></div>}
      {items.length > 0 && <div className="card"><h2>Total: ₹{total.toLocaleString('en-IN')}</h2><a className="button" href="#/checkout">Proceed to Checkout</a></div>}
    </div>
  );
}
