package com.marketplace.service;

import com.marketplace.entity.Category;
import com.marketplace.entity.User;
import com.marketplace.entity.enums.Role;
import com.marketplace.repository.CategoryRepository;
import com.marketplace.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SeedService {
    @Bean
    CommandLineRunner seed(UserRepository users,
                           CategoryRepository categories,
                           PasswordEncoder encoder) {
        return args -> {
            if (!users.existsByEmail("admin@marketplace.local")) {
                User admin = new User();
                admin.fullName = "Marketplace Admin";
                admin.email = "admin@marketplace.local";
                admin.password = encoder.encode("admin123");
                admin.role = Role.ADMIN;
                users.save(admin);
            }

            if (!categories.existsByNameIgnoreCase("Electronics")) {
                Category electronics = new Category();
                electronics.name = "Electronics";
                electronics.description = "Phones, laptops and electronic accessories";
                electronics.level = 1;
                electronics.gstDefault = 18;
                categories.save(electronics);
            }

            if (!categories.existsByNameIgnoreCase("Fashion")) {
                Category fashion = new Category();
                fashion.name = "Fashion";
                fashion.description = "Clothing, footwear and accessories";
                fashion.level = 1;
                fashion.gstDefault = 18;
                categories.save(fashion);
            }
        };
    }
}
