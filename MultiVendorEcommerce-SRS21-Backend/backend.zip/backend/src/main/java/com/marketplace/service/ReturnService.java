//package com.marketplace.service;
//
//import com.marketplace.dto.ReturnRequestDto;
//import com.marketplace.entity.Order;
//import com.marketplace.entity.ReturnRequest;
//import com.marketplace.entity.User;
//import com.marketplace.entity.enums.OrderStatus;
//import com.marketplace.entity.enums.ReturnStatus;
//import com.marketplace.exception.BusinessException;
//import com.marketplace.exception.ResourceNotFoundException;
//import com.marketplace.repository.OrderRepository;
//import com.marketplace.repository.ReturnRepository;
//import com.marketplace.repository.UserRepository;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.time.LocalDateTime;
//import java.util.List;
//
//@Service
//public class ReturnService {
//    private final ReturnRepository returns;
//    private final OrderRepository orders;
//    private final UserRepository users;
//
//    public ReturnService(ReturnRepository returns, OrderRepository orders, UserRepository users) {
//        this.returns = returns;
//        this.orders = orders;
//        this.users = users;
//    }
//
//    @Transactional
//    public ReturnRequest create(ReturnRequestDto request, String email) {
//        User buyer = users.findByEmail(email)
//                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
//        Order order = orders.findById(request.subOrderId)
//                .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
//        if (!order.buyer.id.equals(buyer.id)) {
//            throw new BusinessException("Order does not belong to the logged-in user");
//        }
//        if (order.status != OrderStatus.DELIVERED) {
//            throw new BusinessException("Return can be requested only after delivery");
//        }
//
//        ReturnRequest result = new ReturnRequest();
//        result.buyer = buyer;
//        result.order = order;
//        result.reason = request.reason;
//        result.refundAmount = order.totalAmount;
//        result.status = ReturnStatus.REQUESTED;
//        order.status = OrderStatus.RETURNED;
//        orders.save(order);
//        return returns.save(result);
//    }
//
//    public List<ReturnRequest> byUser(String email) {
//        User buyer = users.findByEmail(email)
//                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
//        return returns.findByBuyerOrderByCreatedAtDesc(buyer);
//    }
//
//    public ReturnRequest updateStatus(java.util.UUID id, ReturnStatus status) {
//        ReturnRequest result = returns.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("Return request not found"));
//        result.status = status;
//        if (status == ReturnStatus.REFUNDED) {
//            result.order.status = OrderStatus.RETURNED;
//            orders.save(result.order);
//        }
//        return returns.save(result);
//    }
//}


package com.marketplace.service;

import com.marketplace.dto.ReturnRequestDto;
import com.marketplace.entity.OrderItem;
import com.marketplace.entity.ReturnRequest;
import com.marketplace.entity.SubOrder;
import com.marketplace.entity.User;
import com.marketplace.entity.enums.ReturnStatus;
import com.marketplace.exception.BusinessException;
import com.marketplace.exception.ResourceNotFoundException;
import com.marketplace.repository.ReturnRepository;
import com.marketplace.repository.SubOrderRepository;
import com.marketplace.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class ReturnService {

    private final ReturnRepository returns;
    private final SubOrderRepository subOrders;
    private final UserRepository users;

    public ReturnService(ReturnRepository returns,
                         SubOrderRepository subOrders,
                         UserRepository users) {
        this.returns = returns;
        this.subOrders = subOrders;
        this.users = users;
    }

    @Transactional
    public ReturnRequest create(ReturnRequestDto request, String email) {

        User buyer = users.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        SubOrder subOrder = subOrders.findById(request.subOrderId)
                .orElseThrow(() -> new ResourceNotFoundException("Sub-order not found"));

        if (!subOrder.order.buyer.id.equals(buyer.id)) {
            throw new BusinessException(
                    "This sub-order does not belong to the logged-in user"
            );
        }

        if (subOrder.status.name().equals("DELIVERED") == false) {
            throw new BusinessException(
                    "Return can be requested only after delivery"
            );
        }

        double refundAmount = 0;

        for (OrderItem item : subOrder.order.items) {
            if (item.vendorId.equals(subOrder.vendor.id)) {
                refundAmount += item.unitPrice * item.quantity;
            }
        }

        ReturnRequest result = new ReturnRequest();
        result.buyer = buyer;
        result.subOrder = subOrder;
        result.reason = request.reason;
        result.refundAmount = refundAmount;
        result.status = ReturnStatus.REQUESTED;

        return returns.save(result);
    }

    public List<ReturnRequest> byUser(String email) {

        User buyer = users.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return returns.findByBuyerOrderByCreatedAtDesc(buyer);
    }

    @Transactional
    public ReturnRequest updateStatus(UUID id, ReturnStatus status) {

        ReturnRequest result = returns.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Return request not found")
                );

        result.status = status;

        return returns.save(result);
    }
}
