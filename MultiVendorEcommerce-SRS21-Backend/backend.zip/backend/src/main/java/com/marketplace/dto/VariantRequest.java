package com.marketplace.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

public class VariantRequest {
    @NotBlank
    public String sku;

    public String size;
    public String colour;
    public String material;

    @Positive
    public double price;

    @PositiveOrZero
    public int stockQuantity;
}
