package com.marketplace.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.marketplace.entity.enums.ReturnStatus;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "returns")
public class
ReturnRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    public UUID id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "sub_order_id")
    @JsonIgnore
    public SubOrder subOrder;

    @ManyToOne(optional = false)
    @JoinColumn(name = "buyer_id")
    @JsonIgnore
    public User buyer;

    public String reason;

    @Enumerated(EnumType.STRING)
    public ReturnStatus status = ReturnStatus.REQUESTED;

    public double refundAmount;
    public LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
    public UUID getSubOrderId() {
        return subOrder != null ? subOrder.id : null;
    }
}
